function simpleCalculator(text, count) {
    return text.repeat(count);
}

console.log(simpleCalculator("abc", 3));
