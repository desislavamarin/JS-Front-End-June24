console.log('Hello from external js file');
