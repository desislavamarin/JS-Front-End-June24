function showText() {
    const moreLinkElement = document.getElementById('more');
    const textElement = document.getElementById('text');

    moreLinkElement.style.display = 'none';
    textElement.style.display = 'inline';
}
